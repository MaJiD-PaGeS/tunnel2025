export {
  delay,
  makeReadableWebSocketStream,
  safeCloseWebSocket as closeWebSocket,
  processVlessHeader,
  vlessJs,
} from './lib/vless-js';
