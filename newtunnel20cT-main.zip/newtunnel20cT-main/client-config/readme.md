# Test local with DNS proxy
